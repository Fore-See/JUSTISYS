<!DOCTYPE html>
<html>

 <head>
 <meta charset="utf-8">
 <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/normalize.css">
 <link rel="stylesheet" href="38_new.css">
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>  -->
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>  -->

 <script src="js/jquery-1.11.2.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
 <script src="js/jquery.smooth-scroll.js"></script>
 
    <script src="39_fimd.js"></script>
 <title>main</title>
 </head>
 <body>

 <?php 
 session_start(); 
 if(isset($_SESSION['Username'])){
	 echo ($_SESSION['Username']);
	 
 }else{
	 echo "尚未登入";
 };
 ?>

 <?php
 if(isset($_SESSION['Username'])){
 ?>
  <a href="customer.php">logout</a>
  <?php
 }
 ?>
 <form method="POST">
 <BR>
 請輸入產品編號<input type="text" name="itemname"></input>
  <BR>
 請輸入產品數量<input type="text" name="count"></input>
 <BR>
  請輸入訂購者<input type="text" name="tset"></input>
 <BR>
 <input type="submit" value="訂購!"></input>
 <BR>
 <?php
 if(isset($_POST["itemname"])&&isset($_POST["count"])){
	  $itemname=$_POST["itemname"];
	  $count=$_POST["count"];
	  $_SESSION['Username']=$_POST["tset"];
	  $USER=$_SESSION['Username'];
	  $query=sprintf("INSERT INTO php.order(empname,itemName,num) VALUES(%s,%s,%s);","'$USER'","'$itemname'","'$count'");
	  require_once('connection.php');
	  $result=mysql_query($query,$connection)or die(/*mysql_error()*/"GG");
 echo "購買完成";
 }

 ?>
 <a href="history.php">查詢購買紀錄</a>

 </body>
</html>