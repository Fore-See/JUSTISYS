<?php
	$connection=mysql_connect('127.0.0.1','root','')or trigger_error(mysql_error(),E_USER_ERROR);//建立連線
	mysql_set_charset('utf8',$connection);//用戶端使用UTF8編碼
	$dbname = 'php';
	mysql_select_db($dbname);//選擇資料庫
?>

