<!DOCTYPE html>
<html>
 <head>
 <meta charset="utf-8">
 <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/normalize.css">
 <link rel="stylesheet" href="38_new.css">
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>  -->
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>  -->

 <script src="js/jquery-1.11.2.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
 <script src="js/jquery.smooth-scroll.js"></script>
 
    <script src="39_fimd.js"></script>
 <title>Jquery</title>
 </head>
 <body>
 <?php
 session_start(); 
 $_SESSION['Username']=null;
 ?>
 <form action="" method="get">
<div>
	會員帳號<input type="text" value="" name="username"></input>
</div>
<div>
	會員密碼<input type="password" value="" name="userpassword"></input>
</div>
<div>
 <input type="submit" value="login"></input>
</div>


<?php

if(isset($_GET['username'])&&isset($_GET['userpassword'])){
$username=$_GET["username"];
$userpassword=$_GET["userpassword"];
require_once('connection.php');
$query = sprintf("select empname,emppassword from customer where empname=%d AND emppassword='%s'",$username,$userpassword);
$result=mysql_query($query,$connection)or die(/*mysql_error()*/"GG");
$row=mysql_fetch_array($result);
if($row['emppassword']==$userpassword&&$row['empname']==$username&&$username!=null&&$userpassword!=null){	
	//echo $row['name'];
	//print_r($row);
	$_SESSION['Username']=$username;
	//echo $_SESSION['Username'];
	header("Location:main.php");
}else{
	echo "帳號密碼輸入錯誤";
}
}
?>





</form>

 </body>
</html>