<!DOCTYPE html>
<html>

 <head>
 <meta charset="utf-8">
 <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/normalize.css">
 <link rel="stylesheet" href="38_new.css">
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>  -->
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>  -->

 <script src="js/jquery-1.11.2.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
 <script src="js/jquery.smooth-scroll.js"></script>
 
    <script src="39_fimd.js"></script>
 <title>main</title>
 </head>
 <body>

<?php
session_start();
$qq=$_SESSION['Username'];
 if(isset($_SESSION['Username'])){
	 //$query=sprintf("SELECT itemName,num FROM `order` WHERE empname=%s","'$qq'");
	 $query=sprintf("SELECT imgName FROM img WHERE name=%s","'$qq'");
	 require_once('connection.php');	 
	 $result=mysql_query($query,$connection)or die(/*mysql_error()*/"GG");
	 $ans=mysql_fetch_array($result);
	 $i=0;
	 mysql_data_seek ($result,$i);
	 while($row = mysql_fetch_array($result)){
		 //print $row['itemName'].":".$row['num'];
		 //print "<button>".$row['itemName']."</button>";
		 //print "<button>".$row['num']."</button>";
	     print "<img src='".$row['imgName']."'>";
	 echo "<BR>";
	}
 }
?>
 </body>
</html>